package com.orderService.enums;

public enum PaymentStatus {
    SUCCESS,
    FAILED,
    PENDING
}
