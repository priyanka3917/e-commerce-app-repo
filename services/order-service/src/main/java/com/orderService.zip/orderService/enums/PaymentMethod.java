package com.orderService.enums;

public enum PaymentMethod {
    CARD,
    UPI,
    COD,
    NETBANKING,
    WALLET
}
