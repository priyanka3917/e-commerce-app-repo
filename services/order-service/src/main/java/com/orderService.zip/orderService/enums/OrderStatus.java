package com.orderService.enums;

public enum OrderStatus {
    PENDING,
    CONFIRMED,
    SHIPPED,
    DELEIVERED,
    CANCELLED
}
